#!/bin/bash
#SBATCH -A f202500010hpcvlabuminhoa
#SBATCH -p normal-arm
#SBATCH -t 00:10:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12
#SBATCH --exclusive
#SBATCH --output=tests/slurm_logs/master_out.o%j
#SBATCH --error=tests/slurm_logs/master_err.e%j

echo "=== MASTER JOB RUNNING ON DEUCALION ==="

THREADS=(1 2 4 )
RUNS=2

OUTDIR="tests/batch_runs"
mkdir -p "$OUTDIR"

echo "[MASTER] Submitting $RUNS runs for each thread count."

for t in "${THREADS[@]}"; do
    echo "[MASTER] Threads = $t"

    for r in $(seq 1 $RUNS); do

        LABEL="run_${r}_threads_${t}"

        sbatch \
            --export=RUN_LABEL="$LABEL",DEST_FOLDER="$OUTDIR" \
            --job-name="$LABEL" \
            tests.sh run "$t" 

        echo "   -> Submitted $LABEL"
    done
done

echo "[MASTER] All jobs submitted."