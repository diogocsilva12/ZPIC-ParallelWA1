#!/bin/bash
#
# =========================================================================== #
# Validate submission archive with validate.sh
# =========================================================================== #
# Usage: sbatch validate_job.sh /path/to/submission.zip
# =========================================================================== #

#SBATCH -A f202500010hpcvlabuminhoa
#SBATCH -p normal-arm
#SBATCH -t 00:05:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --output=tests/slurm_logs/validate_out.o%j
#SBATCH --error=tests/slurm_logs/validate_err.e%j

set -euo pipefail

if [ "$#" -ne 1 ]; then
    echo "Usage: sbatch validate_job.sh /path/to/submission.zip"
    exit 1
fi

ZIP_FILE="$1"

if [ ! -f "$ZIP_FILE" ]; then
    echo "[ERROR] Zip file '$ZIP_FILE' not found."
    exit 1
fi

mkdir -p tests/slurm_logs

# Optional: keep the module stack consistent with other jobs
modules=(
    "GCC/13.3.0"
    "LLVM/19"
)

echo "[INFO] Loading modules for validation job"
ml purge
for module in "${modules[@]}"; do
    echo "[LOAD_MODULE] $module"
    ml "$module"
done

echo "[INFO] Ensuring validate.sh is executable"
chmod +x ./validate.sh

echo "[INFO] Running validator on ${ZIP_FILE}"
./validate.sh "$ZIP_FILE"

echo "[DONE] Validation workflow finished."
